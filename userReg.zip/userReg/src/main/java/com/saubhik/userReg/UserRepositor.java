package com.saubhik.userReg;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class UserRepositor{

	public List<User> getUsersForToday(Date date) {
		
		String sql = "Select user from User where CreatedDate = date";
		
		User user1 = new User("abc", "12345678", "abc@xyz.com", "address");
		User user2 = new User("abc", "12345678", "abc@xyz.com", "address");
		
		return Arrays.asList(user1, user2);
		
	}
	
	
	public User save(User usr) {
		
		return usr;
	}
	
	public User findById(String id) {
		
		return new User("abc", "12345678", "abc@xyz.com", "address");
	}
	
	
}
