package com.saubhik.userReg;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


/*
 * Validation check for user details. Number Format etc.
 * Swagger Documentation
 * Business Exceptions
 * 
 */


@RestController
public class RegistrationController {

	@Autowired
	private UserRepositor repo;
	
	
	@Autowired
	EmailService emailService;
	
	
	/*
	 * @Autowired UploadService uploadSvc;
	 */
	
	@PostMapping(value = "/addUser")
	public String regUser(@Valid User user, BindingResult result) {
		
		if(result.hasErrors()) {
			
			//Throw Some Business Exception 
			return "Validation Failed";
		}
		
		repo.save(user);
		
		return "User registered successfully";
		
	}
	
	
	@GetMapping(value = "/user/{id}")
	public User fetchUserDet(@PathVariable(name = "id") String id) {
		
		if(id != null) {
			User user = repo.findById(id);
			return user;
		}
		
		//Throw Some Business Exception 
		return null;
			
	}
	
	
	@PostMapping(value = "/updateUser")
	public User updateUser(@Valid User user, BindingResult result) {
		
		if(result.hasErrors()) {
			
			return null;
		}
		
		repo.save(user);
		
		return user;
		
		
	}
	
	@GetMapping(value = "listUsersForToday")
	public List<User> getListUsers() {
	
	
		Date dt = new Date();
		List<User> users = repo.getUsersForToday(dt);
		
		if(users != null) {
			
			return users;
		}
			
		return new ArrayList<User>();
			
	}
	
	
	@GetMapping(value = "/sendNotif/{id}")
	public String sendREgNotification(@PathVariable(name = "id") String userId) {
		
		User user = repo.findById(userId);
		
		if(user != null) {
			//emailService.sendMail();
			return "PLs check Mail Box. ";
			
		}
		return "User not found";
	}
	
	@PostMapping(value = "/uploadImage")
	public void uploadImage(byte[] imageStream) {
		
		//uploadSvc.uploadImage(imageStream);
		
		
	}
	
	
}
