package com.saubhik.userReg;

import org.springframework.stereotype.Component;

@Component
public class EmailService {

	
	//@S3CloundService cloudSvc;
	
	
	public void uploadImage(byte[] image) {
		
		//cloudSvc.upload(image);
		
	}
	
	
	
}
