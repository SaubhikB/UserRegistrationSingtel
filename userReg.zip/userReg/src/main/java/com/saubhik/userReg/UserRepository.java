package com.saubhik.userReg;

public class UserRepository {

}
